package com.otmanager.app

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.otmanager.app.data.ThemeMode
import com.otmanager.app.ui.screens.LoanScreen
import com.otmanager.app.ui.screens.LockScreen
import com.otmanager.app.ui.screens.OvertimeScreen
import com.otmanager.app.ui.screens.SettingsScreen
import com.otmanager.app.ui.theme.OvertimeTheme
import com.otmanager.app.viewmodel.MainViewModel

private data class TabItem(val title: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Overtime", Icons.Rounded.CalendarMonth),
    TabItem("Vay nợ", Icons.Rounded.AccountBalance),
    TabItem("Cài đặt", Icons.Rounded.Settings)
)

class MainActivity : FragmentActivity() {
    private val vm: MainViewModel by viewModels()
    private var stoppedAt = 0L

    // Chỉ cho phép MỘT hộp xác thực vân tay tại một thời điểm (tránh hiện chồng nhau)
    private var prompting = false
    private var userCancelled = false
    private var pendingAction: (() -> Unit)? = null

    private var biometricAvailable by mutableStateOf(false)
    private var authMessage by mutableStateOf<String?>(null)

    private lateinit var prompt: BiometricPrompt

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    prompting = false
                    authMessage = null
                    val action = pendingAction
                    pendingAction = null
                    action?.invoke()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    prompting = false
                    pendingAction = null
                    when (errorCode) {
                        BiometricPrompt.ERROR_USER_CANCELED,
                        BiometricPrompt.ERROR_NEGATIVE_BUTTON -> {
                            userCancelled = true
                            authMessage = null
                        }
                        BiometricPrompt.ERROR_CANCELED -> authMessage = null
                        else -> authMessage = errString.toString()
                    }
                }
            }
        )

        refreshBiometric()
        setContent {
            App(
                vm = vm,
                biometricAvailable = biometricAvailable,
                authMessage = authMessage,
                onUnlock = { requestUnlock() },
                onToggleLock = { on ->
                    if (on) {
                        requestAuth("Bật khóa bằng vân tay", "Xác nhận vân tay để bật khóa") {
                            vm.setLockEnabled(true)
                        }
                    } else {
                        requestAuth("Tắt khóa bằng vân tay", "Xác nhận vân tay để tắt khóa") {
                            vm.setLockEnabled(false)
                        }
                    }
                }
            )
        }
    }

    private fun refreshBiometric() {
        biometricAvailable = BiometricManager.from(this)
            .canAuthenticate(AUTHENTICATORS) == BiometricManager.BIOMETRIC_SUCCESS
    }

    /** Mở khóa màn hình chính: người dùng bấm nút "Mở khóa" thì cho phép hiện lại hộp vân tay. */
    private fun requestUnlock() {
        userCancelled = false
        requestAuth("Mở khóa Quản lý tăng ca", "Đặt ngón tay lên cảm biến vân tay") {
            vm.unlock()
        }
    }

    /** Hiện hộp xác thực vân tay; gọi [onSuccess] khi đúng. */
    private fun requestAuth(title: String, subtitle: String, onSuccess: () -> Unit) {
        if (prompting) return
        when (BiometricManager.from(this).canAuthenticate(AUTHENTICATORS)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Unit
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                authMessage = "Điện thoại chưa có vân tay nào. Hãy thêm vân tay trong Cài đặt của máy rồi bấm Thử lại."
                return
            }
            else -> {
                authMessage = "Điện thoại không hỗ trợ hoặc đang tạm thời không dùng được vân tay."
                return
            }
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText("Hủy")
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()
        authMessage = null
        pendingAction = onSuccess
        prompting = true
        prompt.authenticate(info)
    }

    override fun onResume() {
        super.onResume()
        refreshBiometric()
        // Tự hiện hộp vân tay (một lần) khi đang khóa
        if (vm.locked && !prompting && !userCancelled) {
            window.decorView.post {
                if (vm.locked && !prompting && !userCancelled) requestUnlock()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
        userCancelled = false
    }

    override fun onStart() {
        super.onStart()
        // Khóa lại nếu rời ứng dụng từ 30 giây trở lên
        if (stoppedAt != 0L && SystemClock.elapsedRealtime() - stoppedAt >= RELOCK_AFTER_MS) {
            vm.lockIfNeeded()
        }
    }

    private companion object {
        const val RELOCK_AFTER_MS = 30_000L
        const val AUTHENTICATORS = BiometricManager.Authenticators.BIOMETRIC_WEAK
    }
}

@Composable
private fun App(
    vm: MainViewModel,
    biometricAvailable: Boolean,
    authMessage: String?,
    onUnlock: () -> Unit,
    onToggleLock: (Boolean) -> Unit
) {
    val dark = when (vm.settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    OvertimeTheme(darkTheme = dark) {
        if (vm.locked) {
            LockScreen(
                message = authMessage,
                onUnlock = onUnlock
            )
            return@OvertimeTheme
        }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = t.title) },
                            label = { Text(t.title) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .statusBarsPadding()
            ) {
                when (tab) {
                    0 -> OvertimeScreen(
                        month = vm.selectedMonth,
                        entries = vm.entries,
                        settings = vm.settings,
                        onMonthChange = vm::selectMonth,
                        onSaveEntry = vm::saveEntry
                    )
                    1 -> LoanScreen(
                        settings = vm.settings,
                        events = vm.loanEvents,
                        onSaveEvent = vm::saveLoanEvent,
                        onRemoveEvent = vm::removeLoanEvent
                    )
                    else -> SettingsScreen(
                        settings = vm.settings,
                        onChange = vm::updateSettings,
                        exportData = vm::exportBackup,
                        importData = vm::importBackup,
                        lockEnabled = vm.lockEnabled,
                        biometricAvailable = biometricAvailable,
                        onToggleLock = onToggleLock
                    )
                }
            }
        }
    }
}
