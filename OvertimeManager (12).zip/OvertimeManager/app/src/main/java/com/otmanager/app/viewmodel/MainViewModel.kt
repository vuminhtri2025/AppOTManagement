package com.otmanager.app.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.AutoBackup
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.LoanEvent
import com.otmanager.app.data.PinStore
import com.otmanager.app.data.Repository
import com.otmanager.app.widget.OtWidgetProvider
import java.time.LocalDate
import java.time.YearMonth

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(app)
    private val pinStore = PinStore(app)

    var settings by mutableStateOf(repo.loadSettings())
        private set

    var entries by mutableStateOf(repo.loadEntries())
        private set

    var loanEvents by mutableStateOf(repo.loadLoanEvents())
        private set

    var selectedMonth by mutableStateOf(YearMonth.now())
        private set

    // ---- Khóa ứng dụng bằng mã PIN ----

    var hasPin by mutableStateOf(pinStore.hasPin())
        private set

    var biometricEnabled by mutableStateOf(pinStore.isBiometricEnabled())
        private set

    fun setBiometric(enabled: Boolean) {
        pinStore.setBiometricEnabled(enabled)
        biometricEnabled = enabled
    }

    /** Mở khóa thành công bằng vân tay. */
    fun unlockWithBiometric() {
        failCount = 0
        locked = false
    }

    /** Đang khóa: mở app lên là khóa nếu đã đặt mã PIN. */
    var locked by mutableStateOf(pinStore.hasPin())
        private set

    /** Mốc (elapsedRealtime) hết thời gian chờ sau khi nhập sai PIN nhiều lần. */
    var lockoutUntil by mutableLongStateOf(0L)
        private set

    private var failCount = 0

    /** Trả về true nếu mở khóa thành công. */
    fun tryUnlock(pin: String): Boolean {
        if (SystemClock.elapsedRealtime() < lockoutUntil) return false
        if (pinStore.verify(pin)) {
            failCount = 0
            locked = false
            return true
        }
        failCount++
        if (failCount >= MAX_FAILS) {
            failCount = 0
            lockoutUntil = SystemClock.elapsedRealtime() + LOCKOUT_MS
        }
        return false
    }

    fun lockIfNeeded() {
        if (hasPin) locked = true
    }

    fun verifyPin(pin: String): Boolean = pinStore.verify(pin)

    fun setPin(pin: String) {
        pinStore.setPin(pin)
        hasPin = true
    }

    fun clearPin() {
        pinStore.clear()
        hasPin = false
        biometricEnabled = false
        locked = false
    }

    // ---- Dữ liệu ----

    /** Gọi mỗi khi dữ liệu đổi: hẹn sao lưu tự động lên Drive (nếu đã bật). */
    private fun scheduleBackup() {
        AutoBackup.schedule(getApplication<Application>())
    }

    fun updateSettings(new: AppSettings) {
        settings = new
        repo.saveSettings(new)
        scheduleBackup()
    }

    fun saveEntry(date: LocalDate, entry: DayEntry) {
        val map = entries.toMutableMap()
        if (entry.isEmpty) map.remove(date) else map[date] = entry
        entries = map
        repo.saveEntries(map)
        // Cập nhật widget ngoài màn hình chính
        OtWidgetProvider.refresh(getApplication<Application>())
        scheduleBackup()
    }

    /** Thêm kỳ trả nợ mới, hoặc cập nhật nếu đã có kỳ cùng id. */
    fun saveLoanEvent(event: LoanEvent) {
        val list = if (loanEvents.any { it.id == event.id }) {
            loanEvents.map { if (it.id == event.id) event else it }
        } else {
            loanEvents + event
        }
        loanEvents = list
        repo.saveLoanEvents(list)
        scheduleBackup()
    }

    fun removeLoanEvent(id: Long) {
        val list = loanEvents.filter { it.id != id }
        loanEvents = list
        repo.saveLoanEvents(list)
        scheduleBackup()
    }

    fun exportBackup(): String = repo.exportJson()

    /** Khôi phục dữ liệu từ nội dung file sao lưu; trả về true nếu thành công. */
    fun importBackup(text: String): Boolean {
        if (!repo.importJson(text)) return false
        settings = repo.loadSettings()
        entries = repo.loadEntries()
        loanEvents = repo.loadLoanEvents()
        OtWidgetProvider.refresh(getApplication<Application>())
        scheduleBackup()
        return true
    }

    fun selectMonth(month: YearMonth) {
        selectedMonth = month
    }

    private companion object {
        const val MAX_FAILS = 5
        const val LOCKOUT_MS = 30_000L
    }
}
