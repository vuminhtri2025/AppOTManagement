package com.otmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.otmanager.app.ui.components.PinPad

enum class PinFlow { SET, CHANGE, DISABLE }

private enum class PinStep { CURRENT, NEW, CONFIRM }

/**
 * Hộp thoại đặt / đổi / tắt mã PIN.
 *  - SET: nhập mã mới → nhập lại
 *  - CHANGE: nhập mã hiện tại → nhập mã mới → nhập lại
 *  - DISABLE: nhập mã hiện tại
 */
@Composable
fun PinFlowDialog(
    flow: PinFlow,
    verify: (String) -> Boolean,
    onSet: (String) -> Unit,
    onDisable: () -> Unit,
    onDismiss: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    val steps = when (flow) {
        PinFlow.SET -> listOf(PinStep.NEW, PinStep.CONFIRM)
        PinFlow.CHANGE -> listOf(PinStep.CURRENT, PinStep.NEW, PinStep.CONFIRM)
        PinFlow.DISABLE -> listOf(PinStep.CURRENT)
    }
    var index by remember { mutableIntStateOf(0) }
    var newPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val step = steps[index]

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        title = {
            Text(
                text = when (step) {
                    PinStep.CURRENT -> "Nhập mã PIN hiện tại"
                    PinStep.NEW -> "Nhập mã PIN mới (4 số)"
                    PinStep.CONFIRM -> "Nhập lại mã PIN mới"
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (step == PinStep.NEW && flow != PinFlow.DISABLE) {
                    Text(
                        text = "Nếu quên mã PIN, bạn phải gỡ và cài lại ứng dụng rồi khôi phục dữ liệu từ file sao lưu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.onSurfaceVariant
                    )
                }
                error?.let {
                    Text(text = it, style = MaterialTheme.typography.bodySmall, color = c.error)
                }
                PinPad(
                    modifier = Modifier.padding(top = 8.dp),
                    onTyping = { error = null },
                    onComplete = { pin ->
                        when (step) {
                            PinStep.CURRENT -> {
                                if (!verify(pin)) {
                                    error = "Mã PIN không đúng"
                                } else if (index == steps.lastIndex) {
                                    onDisable()
                                    onDismiss()
                                } else {
                                    index++
                                }
                            }
                            PinStep.NEW -> {
                                newPin = pin
                                index++
                            }
                            PinStep.CONFIRM -> {
                                if (pin == newPin) {
                                    onSet(pin)
                                    onDismiss()
                                } else {
                                    error = "Hai lần nhập không khớp, nhập lại mã mới"
                                    index = steps.indexOf(PinStep.NEW)
                                }
                            }
                        }
                    }
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}
