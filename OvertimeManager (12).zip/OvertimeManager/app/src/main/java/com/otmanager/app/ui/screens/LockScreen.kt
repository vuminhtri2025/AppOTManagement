package com.otmanager.app.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.otmanager.app.ui.components.PinPad
import kotlinx.coroutines.delay

/**
 * Màn hình khóa: nhập đúng mã PIN mới vào được ứng dụng.
 * [onSubmit] trả về true nếu mã đúng. [lockoutUntil] là mốc thời gian (elapsedRealtime)
 * hết thời gian chờ sau khi nhập sai nhiều lần.
 */
@Composable
fun LockScreen(
    onSubmit: (String) -> Boolean,
    lockoutUntil: Long,
    biometricEnabled: Boolean = false,
    onBiometric: () -> Unit = {}
) {
    val c = MaterialTheme.colorScheme
    var error by remember { mutableStateOf(false) }
    var remaining by remember { mutableIntStateOf(0) }

    LaunchedEffect(lockoutUntil) {
        while (true) {
            val left = ((lockoutUntil - SystemClock.elapsedRealtime() + 999) / 1000).toInt()
            remaining = left.coerceAtLeast(0)
            if (left <= 0) break
            delay(500)
        }
    }

    // Tự hiện hộp vân tay khi màn hình khóa xuất hiện
    LaunchedEffect(biometricEnabled) {
        if (biometricEnabled) onBiometric()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = c.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Lock,
                contentDescription = null,
                tint = c.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Nhập mã PIN",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = c.onBackground
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = when {
                    remaining > 0 -> "Nhập sai nhiều lần. Thử lại sau $remaining giây"
                    error -> "Mã PIN không đúng"
                    else -> "Quản lý tăng ca"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (remaining > 0 || error) c.error else c.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(32.dp))
            PinPad(
                enabled = remaining == 0,
                onTyping = { error = false },
                onComplete = { pin ->
                    if (!onSubmit(pin)) error = true
                }
            )
            if (biometricEnabled) {
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(onClick = onBiometric) {
                    Icon(Icons.Rounded.Fingerprint, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Dùng vân tay")
                }
            }
        }
    }
}
