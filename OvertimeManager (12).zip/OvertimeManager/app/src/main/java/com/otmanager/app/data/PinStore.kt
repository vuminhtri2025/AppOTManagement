package com.otmanager.app.data

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Lưu mã PIN dưới dạng băm (SHA-256 + muối ngẫu nhiên), không lưu mã gốc.
 * Mã PIN nằm tách riêng khỏi dữ liệu sao lưu nên không bị xuất ra file sao lưu.
 */
class PinStore(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun hasPin(): Boolean = prefs.contains(KEY_HASH) && prefs.contains(KEY_SALT)

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            .joinToString("") { "%02x".format(it) }
        prefs.edit()
            .putString(KEY_SALT, salt)
            .putString(KEY_HASH, hash(salt, pin))
            .apply()
    }

    fun verify(pin: String): Boolean {
        val salt = prefs.getString(KEY_SALT, null) ?: return false
        val saved = prefs.getString(KEY_HASH, null) ?: return false
        return MessageDigest.isEqual(hash(salt, pin).toByteArray(), saved.toByteArray())
    }

    fun clear() {
        prefs.edit().remove(KEY_SALT).remove(KEY_HASH).remove(KEY_BIO).apply()
    }

    /** Cho phép mở khóa bằng vân tay (chỉ có tác dụng khi đã đặt PIN). */
    fun isBiometricEnabled(): Boolean = hasPin() && prefs.getBoolean(KEY_BIO, false)

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIO, enabled).apply()
    }

    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest("$salt:$pin".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private companion object {
        const val PREFS_NAME = "ot_manager_pin"
        const val KEY_SALT = "salt"
        const val KEY_HASH = "hash"
        const val KEY_BIO = "biometric"
    }
}
