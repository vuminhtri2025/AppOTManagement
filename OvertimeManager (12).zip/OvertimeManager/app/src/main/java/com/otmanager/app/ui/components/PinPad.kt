package com.otmanager.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

const val PIN_LENGTH = 4

/** Bàn phím số nhập mã PIN: hiện các chấm tròn ở trên, đủ [length] số thì gọi [onComplete]. */
@Composable
fun PinPad(
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    length: Int = PIN_LENGTH,
    onTyping: () -> Unit = {},
    onComplete: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun press(d: String) {
        if (!enabled || pin.length >= length) return
        pin += d
        onTyping()
        if (pin.length == length) {
            scope.launch {
                delay(150) // để người dùng kịp thấy chấm cuối được tô
                val done = pin
                pin = ""
                onComplete(done)
            }
        }
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        PinDots(filled = pin.length, total = length)
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            for (row in rows) {
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    for (d in row) {
                        PadKey(enabled = enabled, onClick = { press(d) }) {
                            Text(d, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                Spacer(modifier = Modifier.size(KEY_SIZE))
                PadKey(enabled = enabled, onClick = { press("0") }) {
                    Text("0", fontSize = 26.sp, fontWeight = FontWeight.Medium)
                }
                PadKey(
                    enabled = enabled && pin.isNotEmpty(),
                    onClick = { pin = pin.dropLast(1) },
                    filled = false
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Backspace,
                        contentDescription = "Xóa số"
                    )
                }
            }
        }
    }
}

private val KEY_SIZE = 72.dp

@Composable
private fun PadKey(
    enabled: Boolean,
    onClick: () -> Unit,
    filled: Boolean = true,
    content: @Composable () -> Unit
) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .size(KEY_SIZE)
            .clip(CircleShape)
            .background(if (filled) c.surfaceVariant else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.material3.LocalContentColor provides
                (if (enabled) c.onSurface else c.onSurfaceVariant.copy(alpha = 0.4f))
        ) { content() }
    }
}

/** Hàng chấm tròn thể hiện số chữ số đã nhập. */
@Composable
fun PinDots(filled: Int, total: Int = PIN_LENGTH) {
    val c = MaterialTheme.colorScheme
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        for (i in 0 until total) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .then(
                        if (i < filled) Modifier.background(c.primary)
                        else Modifier.border(2.dp, c.outline, CircleShape)
                    )
            )
        }
    }
}
