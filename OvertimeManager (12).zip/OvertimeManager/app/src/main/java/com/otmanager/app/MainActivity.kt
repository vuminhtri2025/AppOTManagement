package com.otmanager.app

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.otmanager.app.data.ThemeMode
import com.otmanager.app.ui.screens.LoanScreen
import com.otmanager.app.ui.screens.LockScreen
import com.otmanager.app.ui.screens.OvertimeScreen
import com.otmanager.app.ui.screens.SettingsScreen
import com.otmanager.app.ui.theme.OvertimeTheme
import com.otmanager.app.viewmodel.MainViewModel

private data class TabItem(val title: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Overtime", Icons.Rounded.CalendarMonth),
    TabItem("Vay nợ", Icons.Rounded.AccountBalance),
    TabItem("Cài đặt", Icons.Rounded.Settings)
)

class MainActivity : FragmentActivity() {
    private val vm: MainViewModel by viewModels()
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            App(
                vm = vm,
                biometricAvailable = canUseBiometric(),
                onUnlockBiometric = { authenticate { vm.unlockWithBiometric() } },
                onToggleBiometric = { on ->
                    if (on) authenticate { vm.setBiometric(true) } else vm.setBiometric(false)
                }
            )
        }
    }

    private fun canUseBiometric(): Boolean =
        BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS

    /** Hiện hộp xác thực vân tay; gọi [onSuccess] khi đúng. Hủy/sai thì quay về nhập PIN. */
    private fun authenticate(onSuccess: () -> Unit) {
        if (!canUseBiometric()) return
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Mở khóa Quản lý tăng ca")
            .setSubtitle("Đặt ngón tay lên cảm biến vân tay")
            .setNegativeButtonText("Dùng mã PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        // Khóa lại nếu rời ứng dụng từ 30 giây trở lên
        if (stoppedAt != 0L && SystemClock.elapsedRealtime() - stoppedAt >= RELOCK_AFTER_MS) {
            vm.lockIfNeeded()
        }
    }

    private companion object {
        const val RELOCK_AFTER_MS = 30_000L
    }
}

@Composable
private fun App(
    vm: MainViewModel,
    biometricAvailable: Boolean,
    onUnlockBiometric: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit
) {
    val dark = when (vm.settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    OvertimeTheme(darkTheme = dark) {
        if (vm.locked) {
            LockScreen(
                onSubmit = vm::tryUnlock,
                lockoutUntil = vm.lockoutUntil,
                biometricEnabled = vm.biometricEnabled && biometricAvailable,
                onBiometric = onUnlockBiometric
            )
            return@OvertimeTheme
        }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = t.title) },
                            label = { Text(t.title) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .statusBarsPadding()
            ) {
                when (tab) {
                    0 -> OvertimeScreen(
                        month = vm.selectedMonth,
                        entries = vm.entries,
                        settings = vm.settings,
                        onMonthChange = vm::selectMonth,
                        onSaveEntry = vm::saveEntry
                    )
                    1 -> LoanScreen(
                        settings = vm.settings,
                        events = vm.loanEvents,
                        onSaveEvent = vm::saveLoanEvent,
                        onRemoveEvent = vm::removeLoanEvent
                    )
                    else -> SettingsScreen(
                        settings = vm.settings,
                        onChange = vm::updateSettings,
                        exportData = vm::exportBackup,
                        importData = vm::importBackup,
                        pinEnabled = vm.hasPin,
                        verifyPin = vm::verifyPin,
                        setPin = vm::setPin,
                        clearPin = vm::clearPin,
                        biometricAvailable = biometricAvailable,
                        biometricEnabled = vm.biometricEnabled,
                        onToggleBiometric = onToggleBiometric
                    )
                }
            }
        }
    }
}
