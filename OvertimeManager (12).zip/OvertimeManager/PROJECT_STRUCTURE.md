# Quản lý tăng ca – Sơ đồ dự án

Ứng dụng Android (Kotlin + Jetpack Compose, Material 3). minSdk 26, targetSdk 34.

```
OvertimeManager/
├── .github/workflows/build.yml      # GitHub Actions: build APK release (R8)
├── .gitignore
├── settings.gradle.kts
├── build.gradle.kts                 # plugin AGP 8.5.2, Kotlin 1.9.24
├── gradle.properties
└── app/
    ├── build.gradle.kts             # Compose, Material3, SDK, dependencies, cấu hình ký APK
    ├── keystore/otmanager.jks       # Khóa ký cố định => cài đè không mất dữ liệu
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/
        │   ├── values/              # strings, colors, themes (sáng)
        │   ├── values-night/        # colors, themes (tối)
        │   ├── drawable/                # icon, nền widget
        │   ├── layout/widget_ot.xml     # Giao diện widget
        │   ├── xml/ot_widget_info.xml   # Cấu hình widget
        │   └── mipmap-anydpi-v26/   # icon ứng dụng (adaptive)
        └── java/com/otmanager/app/
            ├── MainActivity.kt          # Thanh điều hướng 3 tab
            ├── data/
            │   ├── Models.kt            # OtType, DayEntry, AppSettings, ThemeMode
            │   ├── Repository.kt        # Lưu dữ liệu (SharedPreferences + JSON)
            │   ├── PinStore.kt          # Mã PIN (băm SHA-256 + salt) + cờ vân tay
            │   └── AutoBackup.kt        # Sao lưu tự động ra file Drive (WorkManager)
            ├── logic/
            │   ├── SalaryCalculator.kt  # Công thức lương
            │   ├── LoanCalculator.kt    # Bảng trả nợ
            │   └── OtStats.kt           # Giờ OT theo tháng (biểu đồ) + mẫu nhập nhanh
            ├── viewmodel/MainViewModel.kt
            ├── widget/OtWidgetProvider.kt   # Widget: tổng giờ OT tháng này + biểu đồ 12 tháng
            ├── widget/WidgetChart.kt        # Vẽ biểu đồ thành ảnh cho widget
            ├── util/Fmt.kt              # Định dạng tiền, giờ, ngày kiểu VN
            └── ui/
                ├── theme/Color.kt, Theme.kt   # Giao diện sáng/tối
                ├── components/Common.kt       # Card, ô nhập tiền, chọn tháng...
                ├── components/OtBarChart.kt   # Biểu đồ cột chồng giờ OT theo tháng
                ├── components/PinPad.kt       # Bàn phím nhập PIN 4 số
                └── screens/
                    ├── OvertimeScreen.kt      # Tab 1 "Overtime": lịch tháng + thống kê bên dưới
                    ├── DayEditorDialog.kt     # Hộp nhập giờ + 3 mẫu nhập nhanh từ các lần gần nhất
                    ├── LockScreen.kt          # Màn hình khóa bằng PIN / vân tay
                    ├── PinFlowDialog.kt       # Đặt / đổi / tắt mã PIN
                    ├── StatsScreen.kt         # Phần thống kê lương + biểu đồ (nằm dưới lịch)
                    ├── LoanScreen.kt          # Tab 2: vay nợ
                    ├── LoanEventDialog.kt     # Nút +: nhập/sửa kỳ trả nợ (lãi tự tính)
                    └── SettingsScreen.kt      # Tab 3: cài đặt (nút Lưu), khóa PIN, sao lưu Drive tự động, sao lưu/khôi phục thủ công
```

## Đẩy lên GitHub và build APK

1. Tạo repository mới, đẩy toàn bộ thư mục `OvertimeManager` lên (nhánh `main`).
2. Vào tab **Actions** → workflow **Build APK** sẽ tự chạy (hoặc bấm *Run workflow*).
3. Khi chạy xong, tải file **OvertimeManager-debug-apk** ở mục *Artifacts*, giải nén, cài file `.apk` lên điện thoại.

Không cần cài secret nào: keystore đã nằm trong dự án. Workflow dùng Gradle do action cài sẵn nên **không cần** `gradlew` hay `gradle-wrapper.jar`.

## Công thức tính (có thể chỉnh trong `logic/`)

- Đơn giá giờ = (Lương cố định + Trợ cấp) ÷ 192
- Lương tăng ca = Số giờ × Đơn giá giờ × Hệ số (1,5 / 2,1 / 2,0 / 2,7 / 3,0 / 3,9)
- Trừ ra ngoài = Số giờ ra ngoài × Đơn giá giờ
- Thực nhận = Lương gốc + Trợ cấp + Lương tăng ca − Ra ngoài − Thuế khấu trừ
- Vay nợ (dư nợ giảm dần): mỗi kỳ nhập tháng thứ mấy, tháng trả, tiền trả gốc, lãi suất năm.
  Lãi = Dư nợ gốc trước kỳ × Lãi suất năm ÷ 12; Tổng tiền trả = Gốc + Lãi; Dư nợ cuối kỳ = Dư nợ trước kỳ − Gốc
