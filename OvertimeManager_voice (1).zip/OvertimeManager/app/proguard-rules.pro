# Quy tắc R8/ProGuard cho bản release.
# Compose, AndroidX và widget (khai báo trong AndroidManifest) đã được giữ tự động.

# Giữ nguyên enum dữ liệu: cài đặt giao diện được lưu/đọc bằng tên (ThemeMode.valueOf)
-keepclassmembers enum com.otmanager.app.data.** { *; }

# Giữ số dòng để đọc được stacktrace khi app báo lỗi
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
