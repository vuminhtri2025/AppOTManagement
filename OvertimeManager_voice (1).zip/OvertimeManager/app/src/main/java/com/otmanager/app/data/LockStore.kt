package com.otmanager.app.data

import android.content.Context

/**
 * Lưu trạng thái "khóa ứng dụng bằng vân tay" (bật / tắt).
 * Ứng dụng không còn dùng mã PIN. Dữ liệu này nằm tách riêng khỏi file sao lưu.
 *
 * Tương thích bản cũ: nếu máy từng đặt mã PIN thì coi như khóa đang bật
 * (khi đó mở khóa bằng vân tay).
 */
class LockStore(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isEnabled(): Boolean =
        if (prefs.contains(KEY_ENABLED)) prefs.getBoolean(KEY_ENABLED, false)
        else prefs.contains(LEGACY_KEY_HASH)

    fun setEnabled(enabled: Boolean) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, enabled)
            // Xóa dữ liệu PIN cũ (nếu có)
            .remove(LEGACY_KEY_HASH)
            .remove(LEGACY_KEY_SALT)
            .remove(LEGACY_KEY_BIO)
            .apply()
    }

    private companion object {
        const val PREFS_NAME = "ot_manager_pin"
        const val KEY_ENABLED = "lock_enabled"
        const val LEGACY_KEY_HASH = "hash"
        const val LEGACY_KEY_SALT = "salt"
        const val LEGACY_KEY_BIO = "biometric"
    }
}
