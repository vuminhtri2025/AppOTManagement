package com.otmanager.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Tự động sao lưu ra một file mà người dùng chọn một lần (thường nằm trên Google Drive).
 * Mỗi khi dữ liệu thay đổi, một công việc nền được hẹn sau vài giây (gộp các thay đổi liên tiếp),
 * chỉ chạy khi có mạng và tự thử lại nếu thất bại.
 */
object AutoBackup {
    private const val PREFS_NAME = "ot_manager_auto_backup"
    private const val KEY_URI = "uri"
    private const val KEY_LAST_OK = "last_ok"
    private const val KEY_LAST_ERR = "last_err"
    private const val WORK_NAME = "auto_backup"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun uri(context: Context): Uri? =
        prefs(context).getString(KEY_URI, null)?.let { Uri.parse(it) }

    fun setUri(context: Context, uri: Uri?) {
        val editor = prefs(context).edit()
        if (uri == null) {
            editor.remove(KEY_URI).remove(KEY_LAST_ERR)
            cancel(context)
        } else {
            editor.putString(KEY_URI, uri.toString()).remove(KEY_LAST_ERR)
        }
        editor.apply()
    }

    fun lastSuccess(context: Context): Long = prefs(context).getLong(KEY_LAST_OK, 0L)

    fun lastError(context: Context): String? = prefs(context).getString(KEY_LAST_ERR, null)

    internal fun recordSuccess(context: Context) {
        prefs(context).edit()
            .putLong(KEY_LAST_OK, System.currentTimeMillis())
            .remove(KEY_LAST_ERR)
            .apply()
    }

    internal fun recordError(context: Context, message: String) {
        prefs(context).edit().putString(KEY_LAST_ERR, message).apply()
    }

    /** Tên file đang dùng để sao lưu (để hiển thị cho người dùng). */
    fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    /** Hẹn một lần sao lưu sau [delaySeconds] giây; hẹn mới sẽ thay thế hẹn cũ chưa chạy. */
    fun schedule(context: Context, delaySeconds: Long = 15) {
        val app = context.applicationContext
        if (uri(app) == null) return
        val request = OneTimeWorkRequestBuilder<BackupWorker>()
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            )
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(app)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(WORK_NAME)
    }
}

class BackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val uri = AutoBackup.uri(ctx) ?: return Result.success()
        return try {
            withContext(Dispatchers.IO) {
                val bytes = Repository(ctx).exportJson().toByteArray(Charsets.UTF_8)
                // "wt": ghi đè toàn bộ nội dung file cũ
                val out = ctx.contentResolver.openOutputStream(uri, "wt")
                    ?: throw IllegalStateException("Không mở được file sao lưu")
                out.use { it.write(bytes) }
            }
            AutoBackup.recordSuccess(ctx)
            Result.success()
        } catch (e: Exception) {
            AutoBackup.recordError(ctx, e.message ?: "Lỗi không xác định")
            if (runAttemptCount >= 5) Result.failure() else Result.retry()
        }
    }
}
