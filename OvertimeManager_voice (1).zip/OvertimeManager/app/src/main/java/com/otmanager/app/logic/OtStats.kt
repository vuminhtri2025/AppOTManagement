package com.otmanager.app.logic

import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.OtType
import java.time.LocalDate
import java.time.YearMonth

/** Thống kê giờ tăng ca theo tháng (dùng cho biểu đồ trong app và widget). */
object OtStats {
    const val CHART_MONTHS = 12

    /** 12 tháng cố định: từ 11 tháng trước đến tháng hiện tại. */
    fun lastMonths(now: YearMonth = YearMonth.now()): List<YearMonth> =
        (CHART_MONTHS - 1 downTo 0).map { now.minusMonths(it.toLong()) }

    /**
     * Các mẫu nhập nhanh: tối đa [count] kiểu tăng ca khác nhau từ những ngày gần nhất
     * (chỉ lấy giờ tăng ca theo từng mức, bỏ giờ ra ngoài). Bỏ qua ngày [exclude] đang sửa.
     */
    fun recentTemplates(
        entries: Map<LocalDate, DayEntry>,
        exclude: LocalDate? = null,
        count: Int = 3
    ): List<DayEntry> =
        entries.entries
            .filter { it.key != exclude && it.value.totalOt > 0.0 }
            .sortedByDescending { it.key }
            .map { DayEntry(hours = it.value.hours.filterValues { h -> h > 0.0 }) }
            .distinct()
            .take(count)

    /** Số giờ theo từng mức (150%, 210%...) cho mỗi tháng trong danh sách. */
    fun hoursByMonth(
        entries: Map<LocalDate, DayEntry>,
        months: List<YearMonth>
    ): List<Map<OtType, Double>> {
        val index = HashMap<YearMonth, Int>()
        months.forEachIndexed { i, m -> index[m] = i }
        val result = months.map { HashMap<OtType, Double>() }
        for ((date, entry) in entries) {
            val i = index[YearMonth.from(date)] ?: continue
            for ((type, h) in entry.hours) {
                result[i][type] = (result[i][type] ?: 0.0) + h
            }
        }
        return result
    }
}
