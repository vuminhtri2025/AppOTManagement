package com.otmanager.app.voice

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/**
 * Ghi âm từ micro ra file AAC (ADTS) nhỏ gọn, đọc lại thành byte để gửi cho Gemini (MIME audio/aac).
 * Tự dừng sau [MAX_DURATION_MS]. Mọi hàm gọi trên luồng chính.
 */
class VoiceRecorder(context: Context) {

    private val appContext = context.applicationContext
    private var recorder: MediaRecorder? = null
    private var file: File? = null

    val isRecording: Boolean get() = recorder != null

    /** Bắt đầu ghi. [onAutoStop] được gọi khi chạm giới hạn thời gian. Trả về false nếu không mở được micro. */
    fun start(onAutoStop: () -> Unit): Boolean {
        cancel()
        val target = File(appContext.cacheDir, "voice_input.aac")
        @Suppress("DEPRECATION")
        val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(appContext)
        } else {
            MediaRecorder()
        }
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16_000)
            r.setAudioEncodingBitRate(48_000)
            r.setMaxDuration(MAX_DURATION_MS)
            r.setOutputFile(target.absolutePath)
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) onAutoStop()
            }
            r.prepare()
            r.start()
            recorder = r
            file = target
            true
        } catch (e: Exception) {
            try {
                r.release()
            } catch (ignored: Exception) {
            }
            target.delete()
            false
        }
    }

    /** Dừng ghi và trả về nội dung âm thanh; null nếu lỗi hoặc bản ghi quá ngắn. */
    fun stop(): ByteArray? {
        val r = recorder ?: return null
        val f = file
        recorder = null
        file = null
        return try {
            r.stop()
            r.release()
            f?.readBytes()
        } catch (e: Exception) {
            // stop() ném lỗi khi chưa kịp ghi gì
            try {
                r.release()
            } catch (ignored: Exception) {
            }
            null
        } finally {
            f?.delete()
        }
    }

    /** Hủy bản ghi đang chạy (nếu có) và xóa file tạm. */
    fun cancel() {
        val r = recorder
        val f = file
        recorder = null
        file = null
        if (r != null) {
            try {
                r.stop()
            } catch (ignored: Exception) {
            }
            try {
                r.release()
            } catch (ignored: Exception) {
            }
        }
        f?.delete()
    }

    companion object {
        const val MAX_DURATION_MS = 30_000
        /** Bản ghi nhỏ hơn mức này coi như chưa nói gì. */
        const val MIN_AUDIO_BYTES = 1_500
        const val MIME_TYPE = "audio/aac"
    }
}
