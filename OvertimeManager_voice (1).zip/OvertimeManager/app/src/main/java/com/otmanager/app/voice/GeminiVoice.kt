package com.otmanager.app.voice

import android.util.Base64
import com.otmanager.app.data.OtType
import com.otmanager.app.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Kết quả nhận dạng: nội dung nghe được + số giờ theo từng mức. [outHours] null = không nhắc tới. */
data class VoiceResult(
    val transcript: String,
    val hours: Map<OtType, Double>,
    val outHours: Double?
) {
    val isEmpty: Boolean get() = hours.isEmpty() && outHours == null
}

/**
 * Gửi đoạn ghi âm lên Gemini (generateContent, âm thanh gửi kèm dạng base64) và nhờ model
 * trả về JSON số giờ theo từng mức tăng ca. Không dùng thư viện ngoài (HttpURLConnection + org.json).
 *
 * Cố ý KHÔNG dùng responseSchema: bắt model trả JSON bằng câu lệnh rồi tự đọc, nên không phụ thuộc
 * vào cách khai báo schema của từng phiên bản API.
 */
object GeminiVoice {

    class GeminiException(message: String) : Exception(message)

    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/"
    private const val MAX_HOURS = 24.0

    private val PROMPT = """
        You are a data-entry assistant for a Vietnamese worker's daily overtime (OT) log.
        Listen to the audio (spoken Vietnamese) and extract the overtime hours for ONE day.

        Keys (OT rate as percent of the hourly wage):
        - "150": weekday OT (ngày thường)
        - "210": weekday night OT (ngày thường, ca đêm)
        - "200": weekly day-off OT (ngày nghỉ, chủ nhật)
        - "270": day-off night OT (ngày nghỉ, ca đêm)
        - "300": public holiday / Tet OT (ngày lễ, Tết)
        - "390": public holiday / Tet night OT (ngày lễ, Tết, ca đêm)
        - "out": hours the person went out during working time ("ra ngoài"), which are deducted from pay.

        Rules:
        - If the speaker says a percentage ("OT 150%", "tăng ca 210 phần trăm", "một trăm năm mươi"), use that key.
          Only use the day-type description when no percentage is said.
        - Hours are decimal numbers: "bốn tiếng" = 4, "hai tiếng rưỡi" = 2.5, "30 phút" = 0.5, "một tiếng 15 phút" = 1.25.
        - If the same key is mentioned more than once, add the hours together.
        - Ignore words about the date ("hôm nay", "hôm qua", "ngày mai"); everything applies to the single day being edited.
        - Leave out keys that were not mentioned. Never invent values.
        - Reply with ONE JSON object only, no markdown, no explanation, exactly in this shape:
          {"transcript":"<what you heard, in Vietnamese>","hours":{"150":4,"210":2},"out":null}
          Use "out": null when going out was not mentioned. If no overtime was mentioned, "hours" is {}.
    """.trimIndent()

    /** Gửi [audio] (MIME [mime]) lên Gemini và trả về số giờ đã nhận dạng. */
    suspend fun interpret(
        apiKey: String,
        model: String,
        audio: ByteArray,
        mime: String = VoiceRecorder.MIME_TYPE
    ): VoiceResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw GeminiException("Chưa có khóa Gemini API.")
        val modelName = model.trim().removePrefix("models/").ifEmpty { "gemini-3.8-flash" }

        val body = JSONObject().put(
            "contents",
            JSONArray().put(
                JSONObject().put(
                    "parts",
                    JSONArray()
                        .put(JSONObject().put("text", PROMPT))
                        .put(
                            JSONObject().put(
                                "inline_data",
                                JSONObject()
                                    .put("mime_type", mime)
                                    .put("data", Base64.encodeToString(audio, Base64.NO_WRAP))
                            )
                        )
                )
            )
        )

        val conn = URL("$ENDPOINT$modelName:generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey.trim())
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
            if (code !in 200..299) throw GeminiException(describeError(code, text))

            parseModelText(extractText(text))
        } finally {
            conn.disconnect()
        }
    }

    private fun describeError(code: Int, body: String): String {
        val apiMessage = try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        return when {
            (code == 400 && apiMessage?.contains("API key", ignoreCase = true) == true) ||
                code == 401 || code == 403 ->
                "Khóa Gemini API không hợp lệ hoặc chưa được cấp quyền (mã $code)."
            code == 404 ->
                "Không tìm thấy model Gemini. Kiểm tra lại tên model trong Cài đặt."
            code == 429 ->
                "Đã vượt giới hạn sử dụng Gemini, hãy thử lại sau ít phút."
            else ->
                "Gemini báo lỗi $code" + (if (apiMessage.isNullOrBlank()) "" else ": $apiMessage")
        }
    }

    /** Lấy phần chữ trong phản hồi generateContent (bỏ các phần "thought" nếu có). */
    private fun extractText(responseBody: String): String {
        val root = try {
            JSONObject(responseBody)
        } catch (e: Exception) {
            throw GeminiException("Phản hồi của Gemini không đọc được.")
        }
        val parts = root.optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text", ""))
            }
        }
        if (sb.isBlank()) {
            val blocked = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw GeminiException(
                if (blocked.isNotEmpty()) "Gemini từ chối xử lý đoạn ghi âm ($blocked)."
                else "Gemini không trả về kết quả, hãy thử nói lại."
            )
        }
        return sb.toString()
    }

    /** Đọc chuỗi JSON do model trả về (chấp nhận cả khi bị bọc trong ```json ... ```). */
    internal fun parseModelText(text: String): VoiceResult {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) {
            throw GeminiException("Không hiểu kết quả Gemini trả về, hãy thử nói lại.")
        }
        val o = try {
            JSONObject(text.substring(start, end + 1))
        } catch (e: Exception) {
            throw GeminiException("Không hiểu kết quả Gemini trả về, hãy thử nói lại.")
        }

        val hours = HashMap<OtType, Double>()
        val h = o.optJSONObject("hours")
        if (h != null) {
            for (t in OtType.values()) {
                if (!h.has(t.key) || h.isNull(t.key)) continue
                val v = toHours(h.get(t.key)) ?: continue
                if (v > 0.0) hours[t] = v.coerceAtMost(MAX_HOURS)
            }
        }
        val out = if (o.has("out") && !o.isNull("out")) {
            toHours(o.get("out"))?.takeIf { it > 0.0 }?.coerceAtMost(MAX_HOURS)
        } else null

        return VoiceResult(o.optString("transcript", "").trim(), hours, out)
    }

    private fun toHours(value: Any?): Double? = when (value) {
        is Number -> value.toDouble()
        is String -> Fmt.parseDecimal(value)
        else -> null
    }?.takeIf { !it.isNaN() && !it.isInfinite() }
}
