package com.otmanager.app.data

import android.content.Context

/**
 * Cấu hình nhập liệu giọng nói bằng Gemini: khóa API và tên model.
 * Lưu riêng trên máy (không nằm trong file sao lưu, nên khóa không bị lộ khi chia sẻ file sao lưu).
 */
object GeminiConfig {
    /** Model mặc định; có thể đổi trong Cài đặt nếu Google ngừng model này. */
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    private const val PREFS_NAME = "ot_manager_gemini"
    private const val KEY_API = "api_key"
    private const val KEY_MODEL = "model"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun apiKey(context: Context): String =
        prefs(context).getString(KEY_API, null)?.trim().orEmpty()

    fun setApiKey(context: Context, value: String) {
        prefs(context).edit().putString(KEY_API, value.trim()).apply()
    }

    fun model(context: Context): String {
        val saved = prefs(context).getString(KEY_MODEL, null)?.trim()
        return if (saved.isNullOrEmpty()) DEFAULT_MODEL else saved
    }

    fun setModel(context: Context, value: String) {
        prefs(context).edit().putString(KEY_MODEL, value.trim()).apply()
    }
}
