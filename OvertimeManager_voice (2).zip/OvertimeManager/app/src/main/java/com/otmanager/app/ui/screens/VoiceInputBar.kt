package com.otmanager.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.otmanager.app.data.GeminiConfig
import com.otmanager.app.data.OtType
import com.otmanager.app.util.Fmt
import com.otmanager.app.voice.GeminiVoice
import com.otmanager.app.voice.VoiceRecorder
import com.otmanager.app.voice.VoiceResult
import com.otmanager.app.voice.VoiceSpeaker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private enum class VoiceState { IDLE, RECORDING, PROCESSING }

/**
 * Nút "Nhập bằng giọng nói" trong hộp nhập giờ: chạm để bắt đầu nói, chạm lần nữa để dừng.
 * Âm thanh được gửi cho Gemini; kết quả điền vào các ô giờ qua [onResult] (người dùng kiểm tra rồi bấm Lưu).
 */
@Composable
fun VoiceInputBar(onResult: (VoiceResult) -> Unit) {
    val c = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recorder = remember { VoiceRecorder(context) }
    val speaker = remember { VoiceSpeaker(context) }

    var state by remember { mutableStateOf(VoiceState.IDLE) }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    // Đóng hộp thoại giữa chừng thì tắt micro
    DisposableEffect(Unit) {
        onDispose {
            recorder.cancel()
            speaker.shutdown()
        }
    }

    fun fail(text: String) {
        message = text
        isError = true
        state = VoiceState.IDLE
    }

    fun stopAndSend() {
        val audio = recorder.stop()
        if (audio == null || audio.size < VoiceRecorder.MIN_AUDIO_BYTES) {
            fail("Chưa thu được giọng nói, hãy thử lại và nói rõ hơn.")
            return
        }
        state = VoiceState.PROCESSING
        message = null
        scope.launch {
            try {
                val r = GeminiVoice.interpret(
                    apiKey = GeminiConfig.apiKey(context),
                    model = GeminiConfig.model(context),
                    audio = audio
                )
                val speak = GeminiConfig.speakBack(context)
                if (r.isEmpty) {
                    fail(
                        "Không nhận ra số giờ nào" +
                            (if (r.transcript.isNotEmpty()) " (nghe được: “${r.transcript}”)" else "") +
                            ". Hãy nói rõ mức % và số tiếng."
                    )
                    if (speak) speaker.speak("Không nhận ra số giờ nào, hãy nói lại.")
                } else {
                    onResult(r)
                    var note = summary(r)
                    // Đọc to lại để người dùng xác nhận mà không cần nhìn màn hình
                    if (speak && !speaker.speak(spoken(r))) {
                        note += " (Máy chưa có giọng đọc tiếng Việt nên không đọc lại được.)"
                    }
                    message = note
                    isError = false
                    state = VoiceState.IDLE
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: GeminiVoice.GeminiException) {
                fail(e.message ?: "Gemini báo lỗi.")
            } catch (e: Exception) {
                fail("Không kết nối được tới Gemini. Kiểm tra mạng rồi thử lại.")
            }
        }
    }

    fun startRecording() {
        if (GeminiConfig.apiKey(context).isBlank()) {
            fail("Chưa có khóa Gemini API. Vào tab Cài đặt → Nhập giờ bằng giọng nói để dán khóa.")
            return
        }
        speaker.stop() // đang đọc dở thì dừng, để micro không thu lại tiếng đọc
        val ok = recorder.start(onAutoStop = {
            if (state == VoiceState.RECORDING) stopAndSend()
        })
        if (ok) {
            state = VoiceState.RECORDING
            message = null
        } else {
            fail("Không mở được micro. Kiểm tra xem ứng dụng khác có đang dùng micro không.")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecording()
        else fail("Cần cho phép dùng micro để nhập bằng giọng nói.")
    }

    val recording = state == VoiceState.RECORDING
    val processing = state == VoiceState.PROCESSING

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (recording) c.errorContainer else c.primaryContainer)
                .clickable(enabled = !processing) {
                    when (state) {
                        VoiceState.IDLE -> {
                            val granted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                startRecording()
                            } else {
                                try {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } catch (e: Exception) {
                                    fail("Không mở được hộp xin quyền micro. Hãy cấp quyền Micro cho ứng dụng trong Cài đặt của điện thoại.")
                                }
                            }
                        }
                        VoiceState.RECORDING -> stopAndSend()
                        VoiceState.PROCESSING -> Unit
                    }
                }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val fg = if (recording) c.onErrorContainer else c.onPrimaryContainer
            if (processing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = fg
                )
            } else {
                Icon(
                    imageVector = if (recording) Icons.Rounded.Stop else Icons.Rounded.Mic,
                    contentDescription = null,
                    tint = fg,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = when (state) {
                    VoiceState.IDLE -> "Nhập bằng giọng nói"
                    VoiceState.RECORDING -> "Đang nghe… chạm để dừng"
                    VoiceState.PROCESSING -> "Đang xử lý…"
                },
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = fg
            )
        }

        val note = message
        if (note != null) {
            Text(
                text = note,
                style = MaterialTheme.typography.bodySmall,
                color = if (isError) c.error else c.primary,
                modifier = Modifier.padding(top = 6.dp)
            )
        } else if (state == VoiceState.IDLE) {
            Text(
                text = "Ví dụ: “OT 150% 4 tiếng và OT 210% 2 tiếng”",
                style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

/** Câu đọc to, ví dụ: "Đã ghi nhận tăng ca 150 phần trăm 4 tiếng, tăng ca 210 phần trăm 2 tiếng. Hãy kiểm tra lại rồi bấm lưu." */
private fun spoken(r: VoiceResult): String {
    val parts = ArrayList<String>()
    for (t in OtType.values()) {
        val h = r.hours[t] ?: continue
        parts.add("tăng ca ${t.percent} phần trăm ${spokenHours(h)}")
    }
    r.outHours?.let { parts.add("ra ngoài ${spokenHours(it)}") }
    return "Đã ghi nhận " + parts.joinToString(", ") + ". Hãy kiểm tra lại rồi bấm lưu."
}

private fun spokenHours(h: Double): String {
    val whole = Math.floor(h).toInt()
    val frac = h - whole
    return when {
        frac < 0.001 -> "$whole tiếng"
        Math.abs(frac - 0.5) < 0.001 -> if (whole == 0) "nửa tiếng" else "$whole tiếng rưỡi"
        else -> "${Fmt.hours(h)} tiếng"
    }
}

/** Ví dụ: Nghe được “…” → 150%: 4h · 210%: 2h. Kiểm tra lại rồi bấm Lưu. */
private fun summary(r: VoiceResult): String {
    val parts = ArrayList<String>()
    for (t in OtType.values()) {
        val h = r.hours[t] ?: continue
        parts.add("${t.label}: ${Fmt.hours(h)}h")
    }
    r.outHours?.let { parts.add("Ra ngoài: ${Fmt.hours(it)}h") }
    val heard = if (r.transcript.isNotEmpty()) "Nghe được “${r.transcript}” → " else "Đã điền: "
    return heard + parts.joinToString(" · ") + ". Kiểm tra lại rồi bấm Lưu."
}
