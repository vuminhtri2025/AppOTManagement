package com.otmanager.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Đọc to một câu bằng bộ đọc (TextToSpeech) có sẵn của Android, giọng tiếng Việt.
 * Cần máy đã cài giọng đọc tiếng Việt (thường là Google Text-to-speech). Gọi trên luồng chính.
 */
class VoiceSpeaker(context: Context) {

    private var tts: TextToSpeech? = null
    private var initDone = false
    private var ready = false
    private var pending: String? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            initDone = true
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                val r = engine.setLanguage(Locale.forLanguageTag("vi-VN"))
                ready = r != TextToSpeech.LANG_MISSING_DATA &&
                    r != TextToSpeech.LANG_NOT_SUPPORTED &&
                    r != TextToSpeech.ERROR
                val waiting = pending
                if (ready && waiting != null) {
                    engine.speak(waiting, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
                }
            }
            pending = null
        }
    }

    /**
     * Đọc [text]. Trả về false nếu máy không có giọng đọc tiếng Việt (đã biết chắc);
     * true nếu đã đọc hoặc đang chờ bộ đọc khởi động xong để đọc.
     */
    fun speak(text: String): Boolean {
        if (!initDone) {
            pending = text
            return true
        }
        if (!ready) return false
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
        return true
    }

    /** Ngừng đọc (ví dụ khi bắt đầu ghi âm, để micro không thu lại tiếng đọc). */
    fun stop() {
        pending = null
        tts?.stop()
    }

    fun shutdown() {
        pending = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private companion object {
        const val UTTERANCE_ID = "ot_confirm"
    }
}
